package com.example.serveindia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.IOException;
import java.util.ArrayList;

public class Sponsergrantact extends AppCompatActivity {
    private Spinner sp;
    private TextView tv;
    private ImageView iv;
    private EditText et,et2,et3,et4;
    private Button bt_choose,bt_upload,exit;
    private ArrayList<String> al;
    private ArrayAdapter<String> ad;
    private Uri uri;
    String item;


    private int Image_Request_Code = 7;
    private ProgressDialog progressDialog ;
    private StorageReference sr;
    private DatabaseReference dr;
    DatabaseReference mdr;
    String contact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sponsergrantact);
        tv=findViewById(R.id.textView);
        exit=findViewById(R.id.button8);
        iv=findViewById(R.id.imageView);
        et=findViewById(R.id.editText);
        et3=findViewById(R.id.editText7);
        et4=findViewById(R.id.editText8);
        et2=findViewById(R.id.editText2);
        bt_choose=findViewById(R.id.choose);
        bt_upload=findViewById(R.id.upload);
        sp=findViewById(R.id.spinner);
        Intent it=getIntent();
        contact=it.getStringExtra("c");
       // System.out.println("ddddddddddd"+contact);


        progressDialog = new ProgressDialog(Sponsergrantact.this);
        al= new ArrayList<String>();
        al.add("NGO       ");
        al.add("OldAgeHome");
        al.add("Orphanage ");
        ad=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_spinner_dropdown_item,al);
        sp.setAdapter(ad);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){
                    sr= FirebaseStorage.getInstance().getReference().child("sponser'help").child("sponser_Ngo");
                    dr= FirebaseDatabase.getInstance().getReference("sponser'help").child("sponser_Ngo");
                }
                if(position==1){
                    sr= FirebaseStorage.getInstance().getReference().child("sponser'help").child("sponser_OldAgeHomes");
                    dr= FirebaseDatabase.getInstance().getReference("sponser'help").child("sponser_OldAgeHomes");
                }
                if(position==2){
                    sr= FirebaseStorage.getInstance().getReference().child("sponser'help").child("sponser_Orphanagess");
                    dr= FirebaseDatabase.getInstance().getReference("sponser'help").child("sponser_Orphanagess");
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        bt_choose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("Clothes/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Please Select Image"), Image_Request_Code);
            }
        });

        bt_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UploadImageFileToFirebaseStorage();
                removeFromList();
            }
        });
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(Sponsergrantact.this,Thankyouact.class);
                startActivity(it);
            }
        });

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Image_Request_Code && resultCode == RESULT_OK && data != null && data.getData() != null) {
            uri = data.getData();
            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(),uri);
                iv.setImageBitmap(bitmap);
                bt_choose.setText("Image Selected");
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
    public String GetFileExtension(Uri uri) {
        ContentResolver contentResolver = getContentResolver();
        MimeTypeMap mimeTypeMap = MimeTypeMap.getSingleton();
        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri)) ;
    }
    public void UploadImageFileToFirebaseStorage() {
        if (uri!= null) {
            progressDialog.setTitle("Image is Uploading...");
            progressDialog.show();
            final StorageReference storageReference2nd = sr.child(System.currentTimeMillis() + "." + GetFileExtension(uri));
            storageReference2nd.putFile(uri)
                    .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                            storageReference2nd.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                                @Override
                                public void onSuccess(Uri uri) {
                                    String amount = et.getText().toString().trim();
                                    String transid=et2.getText().toString().trim();
                                    String spname = et3.getText().toString().trim();
                                    String  username=et4.getText().toString().trim();
                                    String image=uri.toString();
                                    progressDialog.dismiss();
                                    Toast.makeText(getApplicationContext(), "Image Uploaded Successfully ", Toast.LENGTH_LONG).show();
                                    @SuppressWarnings("VisibleForTests")
                                            Screeshotupload sc=new Screeshotupload(spname,username,amount,transid,image);
                                    String screenshotid=dr.push().getKey();
                                    dr.child(screenshotid).setValue(sc);


                                }
                            });

                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception exception) {
                            progressDialog.dismiss();
                            Toast.makeText(Sponsergrantact.this, exception.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            progressDialog.setTitle("Image is Uploading...");

                        }
                    });
        }
        else {
            Toast.makeText(Sponsergrantact.this, "Please Select Image or Add Image Name", Toast.LENGTH_LONG).show();
        }
    }

    public void removeFromList()
    {

         mdr = FirebaseDatabase.getInstance().getReference().child("Request to help").child("Ngo");
         mdr.addListenerForSingleValueEvent(new ValueEventListener() {
             @Override
             public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                 for(DataSnapshot data:dataSnapshot.getChildren())
                 {
                     Help value = data.getValue(Help.class);
                    // System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"+value.getContact());
                     if(value.getContact().equals(contact))
                     {
                        mdr.child(data.getKey()).removeValue();
                         //System.out.println("$$$EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE"+value.getContact());
                         break;
                     }


                 }

             }

             @Override
             public void onCancelled(@NonNull DatabaseError databaseError) {

             }
         });


    }


}
