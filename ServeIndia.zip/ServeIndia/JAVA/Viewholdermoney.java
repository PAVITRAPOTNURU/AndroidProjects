package com.example.serveindia;

import android.content.Context;
import android.graphics.Paint;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

public class Viewholdermoney  extends RecyclerView.ViewHolder {
    View view;
    public Viewholdermoney(@NonNull View itemView) {
        super(itemView);
        view=itemView;
    }
    public void setdetails(Context context, String spname, String name, String id, String amount,String image)
    {
        TextView sponser=view.findViewById(R.id.rtextview);

        TextView mtitleview4=view.findViewById(R.id.textViewdetails);
        TextView username=view.findViewById(R.id.rtextview2);
        TextView  transid=view.findViewById(R.id.rtextview3);
        TextView amounts=view.findViewById(R.id.rtextview4);

        ImageView mimageview=view.findViewById(R.id.rimageview);
        sponser.setText(spname);
        username.setText(name);
        transid.setText(id);
        amounts.setText(amount);
        mtitleview4.setPaintFlags(mtitleview4.getPaintFlags()| Paint.UNDERLINE_TEXT_FLAG);
        Picasso.get().load(image).into(mimageview);
    }
}


