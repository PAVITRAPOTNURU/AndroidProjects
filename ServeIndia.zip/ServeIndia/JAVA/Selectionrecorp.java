package com.example.serveindia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Selectionrecorp extends AppCompatActivity {
    Button food;
    Button cloth;
    Button book;
    Button educate;
    Button money;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selectionrecorp);
        food=findViewById(R.id.buttonfood);
        cloth=findViewById(R.id.buttoncloth);
        book=findViewById(R.id.buttonbook);
        money=findViewById(R.id.buttonmoney);
        educate=findViewById(R.id.buttoneducate);

        food.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(Selectionrecorp.this,Viewact.class);

                startActivity(it);

            }
        });
        money.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(Selectionrecorp.this,Sponsergrant.class);

                startActivity(it);

            }
        });
        cloth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it2=new Intent(Selectionrecorp.this,Viewactclothorphans.class);
                startActivity(it2);

            }
        });
        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it2=new Intent(Selectionrecorp.this,Viewactbookorp.class);
                startActivity(it2);

            }
        });
        educate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it2=new Intent(Selectionrecorp.this,Viewactivityedcorp.class);
                startActivity(it2);

            }
        });

    }
}



