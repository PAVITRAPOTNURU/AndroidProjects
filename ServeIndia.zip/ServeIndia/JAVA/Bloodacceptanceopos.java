package com.example.serveindia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Bloodacceptanceopos extends AppCompatActivity {
    Button bt,call;
    DatabaseReference mdr;
    String mobile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bloodacceptanceopos);

            bt=findViewById(R.id.acceptopos);
            call=findViewById(R.id.callopos);
            Intent it=getIntent();
            mobile=it.getStringExtra("c");
            call.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                   callto();

                }
            });
            bt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    removeFromList();

                }
            });

        }






    public void removeFromList()
    {

        mdr = FirebaseDatabase.getInstance().getReference().child("Users").child("bloodbanks").child("Donated blood").child("O+");
        mdr.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot data:dataSnapshot.getChildren())
                {
                    Blooddonarslist value = data.getValue(Blooddonarslist.class);
                    // System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"+value.getContact());
                    if(value.getMobile().equals(mobile))
                    {
                        mdr.child(data.getKey()).removeValue();
                        //System.out.println("$$$EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE"+value.getContact());
                        break;
                    }


                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    public void callto()
    {

        mdr = FirebaseDatabase.getInstance().getReference().child("Users").child("bloodbanks").child("Donated blood").child("O+");
        mdr.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot data:dataSnapshot.getChildren())
                {
                    Blooddonarslist value = data.getValue(Blooddonarslist.class);
                    // System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"+value.getContact());
                    //tv.setText(data1);
                    String data1=value.getMobile();
                    //tv.setText(data1);
                    if(data1.isEmpty())
                    {
                        Toast.makeText(getApplicationContext(),"can't make a call",Toast.LENGTH_LONG).show();
                    }
                    else
                    {
                        String s="tel:"+data1;
                        Intent it=new Intent(Intent.ACTION_CALL);
                        it.setData(Uri.parse(s));
                        startActivity(it);
                    }



                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
///////////////////////////////////////////////////////////////////////////////////////////////////////////////

    }




}

