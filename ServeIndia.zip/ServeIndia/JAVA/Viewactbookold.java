package com.example.serveindia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Viewactbookold extends AppCompatActivity {
    RecyclerView mrecyclerview;
    FirebaseDatabase mfbdb;
    DatabaseReference mdr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewactbookold);
        mrecyclerview = findViewById(R.id.recyclerview);
        mrecyclerview.setHasFixedSize(true);
        mrecyclerview.setLayoutManager(new LinearLayoutManager(this));
        mfbdb = FirebaseDatabase.getInstance();
        mdr = mfbdb.getReference().child("Books").child("Books_OldAgeHomes");

    }









    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<ImageUploadInfo,Viewholderbookold> firebaseRecyclerAdapter=new
                FirebaseRecyclerAdapter<ImageUploadInfo, Viewholderbookold>(
                        ImageUploadInfo.class,
                        R.layout.imagebookold,
                        Viewholderbookold.class,
                        mdr
                ){
                    @Override
                    protected void populateViewHolder(Viewholderbookold viewholder, ImageUploadInfo imageUploadInfo, int i) {
                        viewholder.setdetails(getApplicationContext(),imageUploadInfo.getImageURL(),imageUploadInfo.getAddress(),imageUploadInfo.getQuantity(),imageUploadInfo.getItem());
                       // Toast.makeText(getApplicationContext(),"asss",Toast.LENGTH_LONG).show();

                    }
                };
        mrecyclerview.setAdapter(firebaseRecyclerAdapter);




    }
}

