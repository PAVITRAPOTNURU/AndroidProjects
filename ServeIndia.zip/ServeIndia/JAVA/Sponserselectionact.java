package com.example.serveindia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Sponserselectionact extends AppCompatActivity {
    Button orphanages;
    Button oldagehomes;
    Button ngo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sponserselectionact);
        orphanages=findViewById(R.id.button10);
        oldagehomes=findViewById(R.id.button12);
        ngo=findViewById(R.id.button14);
        orphanages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it2=new Intent(Sponserselectionact.this,Wantedhelplistorp.class);
                startActivity(it2);

            }
        });
        ngo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it2=new Intent(Sponserselectionact.this,Wantedhelplistngo.class);
                startActivity(it2);

            }
        });


        oldagehomes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it2=new Intent(Sponserselectionact.this,Wantedhelplistold.class);
                startActivity(it2);

            }
        });
    }
}
