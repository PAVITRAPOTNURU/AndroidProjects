package com.example.serveindia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Blooddonarlogin extends AppCompatActivity {
    EditText donarb_pwd;
    EditText donarb_email;
    Button loginb;
    Button regb;
    FirebaseAuth at;
    private DatabaseReference db;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blooddonarlogin);

        donarb_email = findViewById(R.id.et_emailb);
        donarb_pwd = findViewById(R.id.passwordb);
        loginb = findViewById(R.id.bt_loginb);
        regb = findViewById(R.id.bt_registerb);
        at=FirebaseAuth.getInstance();
        db= FirebaseDatabase.getInstance().getReference().child("Users").child("bloodbanks");
        regb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(Blooddonarlogin.this, Reg_donar.class);
                startActivity(it);

            }
        });
        loginb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Intent it = new Intent(Login_donar.this, Foodactivity.class);
                //startActivity(it);

                String email=donarb_email.getText().toString();
                String pwd=donarb_pwd.getText().toString();
                Toast.makeText(getApplicationContext(),"cool",Toast.LENGTH_LONG).show();

                if(validate(email,donarb_email)&&validate(pwd,donarb_email))
                {
                    Toast.makeText(getApplicationContext(),"Loging In",Toast.LENGTH_SHORT).show();
                    loginDon(email,pwd);

                }
                donarb_email.setText("");
                donarb_pwd.setText("");

            }
        });





    }
    private void loginDon(String email,String password){
        at.signInWithEmailAndPassword(email,password).addOnSuccessListener(this, new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                db.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for(DataSnapshot data: dataSnapshot.getChildren())
                        {
                            if(data.getKey().equals(FirebaseAuth.getInstance().getUid()))
                            {
                                startActivity(new Intent(Blooddonarlogin.this,Bloodbankact.class));

                                break;
                            }

                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_SHORT).show();
            }
        });
    }
    private boolean validate(String string ,EditText editText)
    {
        if(string.isEmpty())
        {
            editText.setError("plz enter the field");
            return false;
        }
        return true;
    }

}