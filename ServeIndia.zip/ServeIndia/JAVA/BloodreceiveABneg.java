package com.example.serveindia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class BloodreceiveABneg extends AppCompatActivity {
    RecyclerView mrecyclerview;
    FirebaseDatabase mfbdb;
    DatabaseReference mdr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bloodreceive_a_bneg);
        mrecyclerview = findViewById(R.id.recyclerview);
        mrecyclerview.setHasFixedSize(true);
        mrecyclerview.setLayoutManager(new LinearLayoutManager(this));
        mfbdb = FirebaseDatabase.getInstance();
        mdr = mfbdb.getReference().child("Users").child("bloodbanks").child("Donated blood").child("AB-");

    }










    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<Blooddonarslist,BloodreceivehelpABneg> firebaseRecyclerAdapter=new
                FirebaseRecyclerAdapter<Blooddonarslist,BloodreceivehelpABneg>(
                        Blooddonarslist.class,
                        R.layout.bloodviewlayout,
                        BloodreceivehelpABneg.class,
                        mdr
                ){

                    @Override
                    protected void populateViewHolder(BloodreceivehelpABneg bloodreceivehelp, Blooddonarslist blooddonarslist, int i) {
                        bloodreceivehelp.setdetails(getApplicationContext(),blooddonarslist.getUsername(),blooddonarslist.getMobile(),blooddonarslist.getGender());
                    }
                };
        mrecyclerview.setAdapter(firebaseRecyclerAdapter);




    }
}
