
package com.example.serveindia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Selectionactivity_org extends AppCompatActivity {
    Button help;
    Button receive;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selectionorg);
        help=findViewById(R.id.bt_help);
        receive=findViewById(R.id.bt_received);
        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(Selectionactivity_org.this,Sponseringmoney.class);
                startActivity(it);

            }
        });
        receive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent it=new Intent(Selectionactivity_org.this,Selectionrecorp.class);
                startActivity(it);

            }
        });
    }
}
