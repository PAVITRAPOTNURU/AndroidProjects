package com.example.serveindia;

import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class Hoderhelperorphanges extends RecyclerView.ViewHolder {
    View view;
    public Hoderhelperorphanges(@NonNull View itemView) {
        super(itemView);
        view=itemView;
    }


    public void setdetails(Context context, String name, String amount, String purpose, final String contact, String add) {
        TextView names = view.findViewById(R.id.rtextview);
        RelativeLayout rl=view.findViewById(R.id.rel);
        TextView mtitleview4 = view.findViewById(R.id.textViewdetails);
        TextView amounts = view.findViewById(R.id.rtextview2);
        TextView purposes = view.findViewById(R.id.rtextview3);
        TextView contacts = view.findViewById(R.id.rtextview4);
        TextView address = view.findViewById(R.id.rtextview5);

        ImageView mimageview = view.findViewById(R.id.rimageview);
        names.setText(name);
        contacts.setText(contact);
        address.setText(add);
        amounts.setText(amount);
        purposes.setText(purpose);
        rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(view.getContext(),Sponsergrantactivityorp.class);
                it.putExtra("c",contact);
                view.getContext().startActivity(it);



            }
        });





        mtitleview4.setPaintFlags(mtitleview4.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
    }


}
