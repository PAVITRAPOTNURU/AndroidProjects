package com.example.serveindia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Reg_oldagehomes extends AppCompatActivity {
    EditText regold_name;
    EditText regold_pwd;
    EditText regold_email;
    EditText regold_phone;
    EditText regold_address;
    Button regold_save;
    Button regold_cancel;
    FirebaseAuth mAuth_old;
    DatabaseReference db_old;
    String username_old;
    String phone_old;
    String email_old;
    String pwd_old;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg_oldagehomes);
        regold_name=findViewById(R.id.et_registeroldagehomes_username);
        regold_pwd=findViewById(R.id.et_registeroldagehomes_pwd);
        regold_email=findViewById(R.id.et_registeroldagehomes_email);
        regold_phone=findViewById(R.id.et_registeroldagehomes_phone);
        regold_address=findViewById(R.id.et_registeroldagehomes_address);
        regold_save=findViewById(R.id.bt_registeroldagehomes_save);
        regold_cancel=findViewById(R.id.bt_registeroldagehomes_cancel);
        mAuth_old= FirebaseAuth.getInstance();
        db_old= FirebaseDatabase.getInstance().getReference("Users").child("Oldagehomes");
        regold_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username_old=regold_name.getText().toString();
                phone_old=regold_phone.getText().toString();
                email_old=regold_email.getText().toString();
                pwd_old=regold_pwd.getText().toString();

                if(validate(username_old,regold_name)&&validate(phone_old,regold_phone)&&validate(email_old,regold_email)&&validate(pwd_old,regold_pwd))
                {
                    Toast.makeText(getApplicationContext(),"validated",Toast.LENGTH_LONG).show();
                    register(email_old,pwd_old);


                }
                regold_pwd.setText("");
                regold_email.setText("");
                regold_address.setText("");
                regold_name.setText("");
                regold_phone.setText("");


            }


        });


    }

    private void register(final String email, final String pwd) {
        mAuth_old.createUserWithEmailAndPassword(email, pwd)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            User user=new User(username_old,phone_old,email_old);
                            db_old.child(mAuth_old.getUid()).setValue(user);
                            Toast.makeText(Reg_oldagehomes.this,"Succes",Toast.LENGTH_LONG).show();

                            Intent it=new Intent(Reg_oldagehomes.this,Login_donar.class);
                            startActivity(it);


                        }


                    }
                }).addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(Reg_oldagehomes.this,e.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }

    private boolean validate(String string ,EditText editText)
    {
        if(string.isEmpty())
        {
            editText.setError("plz enter the field");
            return  false;
        }
        return true;
    }
    }

