package com.example.serveindia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Login_oldagehomes extends AppCompatActivity {

    EditText old_pwd;
    EditText old_email;
    Button login_old;
    Button reg_old;
    FirebaseAuth at_old;
    DatabaseReference db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_oldagehomes);

        old_email = findViewById(R.id.et_loginold_email);
        old_pwd = findViewById(R.id.et_loginold_pwd);
        login_old = findViewById(R.id.bt_loginold_login);
        reg_old = findViewById(R.id.bt_loginold_register);
        at_old = FirebaseAuth.getInstance();
         db = FirebaseDatabase.getInstance().getReference().child("Users").child("Oldagehomes");
        reg_old.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(Login_oldagehomes.this, Reg_oldagehomes.class);
                startActivity(it);

            }
        });
        login_old.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Intent it = new Intent(Login_donar.this, Foodactivity.class);
                //startActivity(it);

                String email = old_email.getText().toString();
                String pwd = old_pwd.getText().toString();
                Toast.makeText(getApplicationContext(), "cool", Toast.LENGTH_LONG).show();

                if (validate(email, old_email) && validate(pwd, old_email)) {
                    Toast.makeText(getApplicationContext(), "validated", Toast.LENGTH_LONG).show();
                    loginDon(email, pwd);

                }


            }
        });

    }

    private void loginDon(String email, String password) {
        at_old.signInWithEmailAndPassword(email, password).addOnSuccessListener(this, new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                db.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot data : dataSnapshot.getChildren()) {
                            if (data.getKey().equals(FirebaseAuth.getInstance().getUid())) {
                                startActivity(new Intent(Login_oldagehomes.this, Selectionactivityorgold.class));
                                break;
                            }
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });


                old_email.setText("");
                old_pwd.setText("");

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean validate(String string, EditText editText) {
        if (string.isEmpty()) {
            editText.setError("plz enter the field");
            return false;
        }
        return true;
    }
}

