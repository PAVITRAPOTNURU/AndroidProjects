package com.example.serveindia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Bloodgroupslistrec extends AppCompatActivity {
    Button opos1,oneg1,apos1,aneg1,bpos1,bneg1,abpos1,abneg1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bloodgroupslistrec);
        opos1=findViewById(R.id.opos);
        oneg1=findViewById(R.id.oneg);
        apos1=findViewById(R.id.apos);
        aneg1=findViewById(R.id.aneg);
        bpos1=findViewById(R.id.bpos);
        bneg1=findViewById(R.id.bneg);
        abpos1=findViewById(R.id.abpos);
        abneg1=findViewById(R.id.abneg);
        opos1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(Bloodgroupslistrec.this,Bloodreceive.class);
                startActivity(it);

            }
        });
        oneg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(Bloodgroupslistrec.this,BloodreceiveOneg.class);
                startActivity(it);

            }
        });
        apos1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(Bloodgroupslistrec.this,BloodreceiveApos.class);
                startActivity(it);

            }
        });
        aneg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(Bloodgroupslistrec.this,BloodreceiveAneg.class);
                startActivity(it);

            }
        });
        bpos1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(Bloodgroupslistrec.this,BloodreceiveBpos.class);
                startActivity(it);

            }
        });
        bneg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(Bloodgroupslistrec.this,BloodreceiveBneg.class);
                startActivity(it);

            }
        });
        abpos1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(Bloodgroupslistrec.this,BloodreceiveABpos.class);
                startActivity(it);

            }
        });
        abneg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(Bloodgroupslistrec.this,BloodreceiveABneg.class);
                startActivity(it);

            }
        });

    }
}
