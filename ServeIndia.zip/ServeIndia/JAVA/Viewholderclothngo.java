package com.example.serveindia;

import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

public class Viewholderclothngo extends RecyclerView.ViewHolder {
    View view;
    public Viewholderclothngo(@NonNull View itemView) {
        super(itemView);
        view=itemView;
    }
    public void setdetails(Context context, final String imageURL, String quantity, String address, String item)
    {
        TextView mtitleview=view.findViewById(R.id.rtextview);

        TextView mtitleview4=view.findViewById(R.id.textViewdetails);
        RelativeLayout rl=view.findViewById(R.id.rel);
        TextView mtitleview2=view.findViewById(R.id.rtextview2);
        TextView mtitleview3=view.findViewById(R.id.rtextview3);
        rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(view.getContext(),Acceptanceclothngo.class);
                it.putExtra("c",imageURL);
                view.getContext().startActivity(it);



            }
        });


        ImageView mimageview=view.findViewById(R.id.rimageview);
        mtitleview.setText(address);
        mtitleview2.setText(quantity);
        mtitleview3.setText(item);
        mtitleview4.setPaintFlags(mtitleview4.getPaintFlags()| Paint.UNDERLINE_TEXT_FLAG);
        Picasso.get().load(imageURL).into(mimageview);
    }
}
