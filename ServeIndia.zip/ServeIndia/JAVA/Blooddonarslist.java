package com.example.serveindia;

public class Blooddonarslist {
    String username;
    String mobile;
    String gender;
    String bloodgroup;
    Blooddonarslist()
    {

    }
    public Blooddonarslist(String name,String bloodgroup, String phone, String gender) {
        this.username = name;
        this.bloodgroup=bloodgroup;
        this.mobile = phone;
        this.gender = gender;

    }

    public Blooddonarslist(String name, String phone, String gender_b) {
        this.username = name;
        this.mobile = phone;
        this.gender = gender_b;
    }

    public String getBloodgroup() {
        return bloodgroup;
    }

    public void setBloodgroup(String bloodgroup) {
        this.bloodgroup = bloodgroup;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
}
