package com.example.serveindia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Viewactivityedcngo extends AppCompatActivity {
    RecyclerView mrecyclerview;
    FirebaseDatabase mfbdb;
    DatabaseReference mdr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_viewactivityedcngo);

            mrecyclerview = findViewById(R.id.recyclerview);
            mrecyclerview.setHasFixedSize(true);
            mrecyclerview.setLayoutManager(new LinearLayoutManager(this));
            mfbdb = FirebaseDatabase.getInstance();
            mdr = mfbdb.getReference().child("Child Care").child("Childcare_Ngo");

        }


        @Override
        protected void onStart () {
            super.onStart();
            FirebaseRecyclerAdapter<ImageUploadInfo, Viewholderedcngo> firebaseRecyclerAdapter = new
                    FirebaseRecyclerAdapter<ImageUploadInfo, Viewholderedcngo>(
                            ImageUploadInfo.class,
                            R.layout.imageedcorp,
                            Viewholderedcngo.class,
                            mdr
                    ) {
                        @Override
                        protected void populateViewHolder(Viewholderedcngo viewholder, ImageUploadInfo imageUploadInfo, int i) {
                            viewholder.setdetails(getApplicationContext(), imageUploadInfo.getImageURL(), imageUploadInfo.getAddress(), imageUploadInfo.getQuantity(), imageUploadInfo.getItem());
                            //Toast.makeText(getApplicationContext(), "asss", Toast.LENGTH_LONG).show();

                        }
                    };
            mrecyclerview.setAdapter(firebaseRecyclerAdapter);


        }
    }



