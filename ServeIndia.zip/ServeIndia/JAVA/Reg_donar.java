package com.example.serveindia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Reg_donar extends AppCompatActivity {
    EditText regdonar_name;
    EditText regdonar_pwd;
    EditText regdonar_email;
    EditText regdonar_phone;
    EditText regdonar_address;
    Button regdonar_save;
    Button regdonar_cancel;
    FirebaseAuth mAuth;
    DatabaseReference db;
    String username;
    String phone;
    String email;
    String pwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg_donar);
        regdonar_name=findViewById(R.id.et_registerdonar_username);
        regdonar_pwd=findViewById(R.id.et_registerdonar_pwd);
        regdonar_email=findViewById(R.id.et_registerdonar_email);
        regdonar_phone=findViewById(R.id.et_registerdonar_phone);
        regdonar_address=findViewById(R.id.et_registerdonar_address);
        regdonar_save=findViewById(R.id.bt_registerdonar_save);
        regdonar_cancel=findViewById(R.id.bt_registerdonar_cancel);
        mAuth= FirebaseAuth.getInstance();
        db= FirebaseDatabase.getInstance().getReference("Users").child("Donars");
        regdonar_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username=regdonar_name.getText().toString();
                phone=regdonar_phone.getText().toString();
                email=regdonar_email.getText().toString();
                pwd=regdonar_pwd.getText().toString();

                if(validate(username,regdonar_name)&&validate(phone,regdonar_phone)&&validate(email,regdonar_email)&&validate(pwd,regdonar_pwd))
                {
                    Toast.makeText(getApplicationContext(),"validated",Toast.LENGTH_LONG).show();
                    register(email,pwd);


                }
                regdonar_pwd.setText("");
                regdonar_email.setText("");
                regdonar_phone.setText("");
                regdonar_name.setText("");
                regdonar_address.setText("");



            }


        });


    }

    private void register(final String email, final String pwd) {
        mAuth.createUserWithEmailAndPassword(email, pwd)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            User user=new User(username,phone,email);
                            db.child(mAuth.getUid()).setValue(user);
                            Toast.makeText(Reg_donar.this,user.getUsername(),Toast.LENGTH_LONG).show();

                            Intent it=new Intent(Reg_donar.this,Login_donar.class);
                            startActivity(it);


                        }


                    }
                }).addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(Reg_donar.this,e.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }

    private boolean validate(String string ,EditText editText)
    {
        if(string.isEmpty())
        {
            editText.setError("plz enter the field");
            return  false;
        }
        return true;
    }
}
