package com.example.serveindia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Selectionrecold extends AppCompatActivity {
    Button food;
    Button cloth;
    Button book;
    Button educate;
    Button money;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selectionrecold);
        food=findViewById(R.id.buttonfood2);
        cloth=findViewById(R.id.buttoncloth2);
        book=findViewById(R.id.buttonbook2);
        money=findViewById(R.id.buttonmoney2);
        educate=findViewById(R.id.buttoneducate2);

        food.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(Selectionrecold.this,Viewactold.class);

                startActivity(it);

            }
        });
        money.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(Selectionrecold.this,moneyfromspontoold.class);

                startActivity(it);

            }
        });

        cloth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it2=new Intent(Selectionrecold.this,Viewactclothold.class);
                startActivity(it2);

            }
        });
        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it2=new Intent(Selectionrecold.this,Viewactbookold.class);
                startActivity(it2);

            }
        });
        educate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it2=new Intent(Selectionrecold.this,Viewactivityedcold.class);
                startActivity(it2);

            }
        });

    }
}




