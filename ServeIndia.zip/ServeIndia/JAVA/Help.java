package com.example.serveindia;

public class Help {
    String id;
    String amount;
    String purpose;
    String name;
    String address;
    String contact;
    public Help()
    {

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public Help(String id,String name, String amount, String purpose,String contact,String address)
    {
        this.id=id;
        this.name=name;
        this.amount=amount;
        this.purpose=purpose;
        this.contact=contact;
        this.address=address;

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }
}
