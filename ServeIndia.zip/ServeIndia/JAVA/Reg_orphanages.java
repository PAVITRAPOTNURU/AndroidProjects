package com.example.serveindia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Reg_orphanages extends AppCompatActivity {
    EditText regorp_name;
    EditText regorp_pwd;
    EditText regorp_email;
    EditText regorp_phone;
    EditText regorp_address;
    Button regorp_save;
    Button regorp_cancel;
    FirebaseAuth mAuthorp;
    DatabaseReference dborp;
    String username_orp;
    String phone_orp;
    String email_orp;
    String pwd_orp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg_orphanages);
        regorp_name=findViewById(R.id.et_registerorphanages_username);
        regorp_pwd=findViewById(R.id.et_registerorphanages_pwd);
        regorp_email=findViewById(R.id.et_registerorphanages_email);
        regorp_phone=findViewById(R.id.et_registerorphanages_phone);
        regorp_address=findViewById(R.id.et_registerorphanages_address);
        regorp_save=findViewById(R.id.bt_registerorphanages_save);
        regorp_cancel=findViewById(R.id.bt_registerorphanages_cancel);
        mAuthorp= FirebaseAuth.getInstance();
        dborp= FirebaseDatabase.getInstance().getReference("Users").child("orphanages");
        regorp_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username_orp=regorp_name.getText().toString();
                phone_orp=regorp_phone.getText().toString();
                email_orp=regorp_email.getText().toString();
                pwd_orp=regorp_pwd.getText().toString();

                if(validate(username_orp,regorp_name)&&validate(phone_orp,regorp_phone)&&validate(email_orp,regorp_email)&&validate(pwd_orp,regorp_pwd))
                {
                    Toast.makeText(getApplicationContext(),"validated",Toast.LENGTH_LONG).show();
                    register(email_orp,pwd_orp);


                }
                regorp_address.setText("");
                regorp_email.setText("");
                regorp_name.setText("");
                regorp_phone.setText("");
                regorp_pwd.setText("");


            }


        });


    }

    private void register(final String email, final String pwd) {
        mAuthorp.createUserWithEmailAndPassword(email, pwd)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            User user=new User(username_orp,phone_orp,email_orp);
                            dborp.child(mAuthorp.getUid()).setValue(user);
                            Toast.makeText(Reg_orphanages.this,"Succes",Toast.LENGTH_LONG).show();

                            Intent it=new Intent(Reg_orphanages.this,Login_donar.class);
                            startActivity(it);


                        }


                    }
                }).addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(Reg_orphanages.this,e.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }

    private boolean validate(String string ,EditText editText)
    {
        if(string.isEmpty())
        {
            editText.setError("plz enter the field");
            return  false;
        }
        return true;
    }
    }

