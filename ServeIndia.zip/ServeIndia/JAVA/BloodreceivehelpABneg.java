package com.example.serveindia;

import android.content.Context;
import android.content.Intent;
import android.graphics.Paint;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class BloodreceivehelpABneg  extends RecyclerView.ViewHolder {
    View view;
    public BloodreceivehelpABneg(@NonNull View itemView) {
        super(itemView);
        view=itemView;
    }
    public void setdetails(Context context, String name,  final String contact, String gen) {
        TextView names = view.findViewById(R.id.rtextview);

        TextView mtitleview4 = view.findViewById(R.id.textViewdetails);

        TextView contacts = view.findViewById(R.id.rtextview3);
        TextView gender = view.findViewById(R.id.rtextview4);
        RelativeLayout rl=view.findViewById(R.id.rel);

        rl.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(view.getContext(),BloodacceptanceABneg.class);
                it.putExtra("c",contact);
                view.getContext().startActivity(it);



            }
        });

        names.setText(name);
        contacts.setText(contact);

        gender.setText(gen);
        mtitleview4.setPaintFlags(mtitleview4.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
    }
}
