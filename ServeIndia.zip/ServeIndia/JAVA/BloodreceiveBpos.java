package com.example.serveindia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class BloodreceiveBpos extends AppCompatActivity {
    RecyclerView mrecyclerview;
    FirebaseDatabase mfbdb;
    DatabaseReference mdr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bloodreceive_bpos);
        mrecyclerview = findViewById(R.id.recyclerview);
        mrecyclerview.setHasFixedSize(true);
        mrecyclerview.setLayoutManager(new LinearLayoutManager(this));
        mfbdb = FirebaseDatabase.getInstance();
        mdr = mfbdb.getReference().child("Users").child("bloodbanks").child("Donated blood").child("B+");

    }











    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<Blooddonarslist,BloodreceivehelpBpos> firebaseRecyclerAdapter=new
                FirebaseRecyclerAdapter<Blooddonarslist,BloodreceivehelpBpos>(
                        Blooddonarslist.class,
                        R.layout.bloodviewlayout,
                        BloodreceivehelpBpos.class,
                        mdr
                ){

                    @Override
                    protected void populateViewHolder(BloodreceivehelpBpos bloodreceivehelp, Blooddonarslist blooddonarslist, int i) {
                        bloodreceivehelp.setdetails(getApplicationContext(),blooddonarslist.getUsername(),blooddonarslist.getMobile(),blooddonarslist.getGender());
                    }
                };
        mrecyclerview.setAdapter(firebaseRecyclerAdapter);




    }
}
