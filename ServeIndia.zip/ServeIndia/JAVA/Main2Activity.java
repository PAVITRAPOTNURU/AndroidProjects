package com.example.serveindia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;

import java.util.ArrayList;

public class Main2Activity extends AppCompatActivity {
    Button upload,exit;
    EditText username,mobile,gender;

    private FirebaseAuth mAuth;
    private DatabaseReference db_blooddonar;
    private ArrayList<String> al;
    private ArrayAdapter<String> ad;
    private Spinner sp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        upload=findViewById(R.id.button);
        exit=findViewById(R.id.button2);
        username=findViewById(R.id.editText3);
        mobile=findViewById(R.id.editText4);
        gender=findViewById(R.id.editText5);
        mAuth=FirebaseAuth.getInstance();
        sp=findViewById(R.id.spinner2);
        al= new ArrayList<String>();
        al.add("O+");
        al.add("O-");
        al.add("AB-");
        al.add("AB+");
        al.add("A+");
        al.add("A-");
        al.add("B-");
        al.add("B+");
        ad=new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_spinner_dropdown_item,al);
        sp.setAdapter(ad);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(position==0){
                    db_blooddonar= FirebaseDatabase.getInstance().getReference().child("Users").child("bloodbanks").child("Donated blood").child("O+");
                }
                if(position==1){
                    db_blooddonar= FirebaseDatabase.getInstance().getReference().child("Users").child("bloodbanks").child("Donated blood").child("O-");
                }
                if(position==2){
                    db_blooddonar= FirebaseDatabase.getInstance().getReference().child("Users").child("bloodbanks").child("Donated blood").child("AB-");
                }
                if(position==3){
                    db_blooddonar= FirebaseDatabase.getInstance().getReference().child("Users").child("bloodbanks").child("Donated blood").child("AB+");
                }
                if(position==4){
                    db_blooddonar= FirebaseDatabase.getInstance().getReference().child("Users").child("bloodbanks").child("Donated blood").child("A+");
                }
                if(position==5){
                    db_blooddonar= FirebaseDatabase.getInstance().getReference().child("Users").child("bloodbanks").child("Donated blood").child("A-");
                }
                if(position==6){
                    db_blooddonar= FirebaseDatabase.getInstance().getReference().child("Users").child("bloodbanks").child("Donated blood").child("B-");
                }
                if(position==7){
                    db_blooddonar= FirebaseDatabase.getInstance().getReference().child("Users").child("bloodbanks").child("Donated blood").child("B+");
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        db_blooddonar= FirebaseDatabase.getInstance().getReference().child("Users").child("bloodbanks").child("Donated blood");
        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name=username.getText().toString().trim();
                String phone=mobile.getText().toString().trim();
                String gender_b=gender.getText().toString().trim();

                String id=db_blooddonar.push().getKey();
                Blooddonarslist ob=new Blooddonarslist(name,phone,gender_b);

                db_blooddonar.child(id).setValue(ob);
                thank();


                Toast.makeText(getApplicationContext(),"Success...",Toast.LENGTH_SHORT).show();

            }
        });


    }
    public void thank(){
        Intent it=new Intent(Main2Activity.this,Thankyouact.class);
        startActivity(it);


    }
}
