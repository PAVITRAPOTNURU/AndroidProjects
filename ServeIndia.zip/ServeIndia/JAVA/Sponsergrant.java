package com.example.serveindia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Sponsergrant extends AppCompatActivity {
    RecyclerView mrecyclerview;
    FirebaseDatabase mfbdb;
    DatabaseReference mdr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sponsergrant);
        mrecyclerview = findViewById(R.id.recyclerview);
        mrecyclerview.setHasFixedSize(true);
        mrecyclerview.setLayoutManager(new LinearLayoutManager(this));
        mfbdb = FirebaseDatabase.getInstance();
        mdr = mfbdb.getReference().child("sponser'help").child("sponser_Orphanagess");
    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<Screeshotupload,Viewholdermoney> firebaseRecyclerAdapter=new
                FirebaseRecyclerAdapter<Screeshotupload, Viewholdermoney>(
                        Screeshotupload.class,
                        R.layout.imagemoney,
                        Viewholdermoney.class,
                        mdr
                ){

                    @Override
                    protected void populateViewHolder(Viewholdermoney viewholdermoney, Screeshotupload screeshotupload, int i) {
                        viewholdermoney.setdetails(getApplicationContext(),screeshotupload.getSponsername(),screeshotupload.getName(),screeshotupload.getTransid(),
                                screeshotupload.getAmountoffered(),screeshotupload.getImageurl());
                    }
                };
        mrecyclerview.setAdapter(firebaseRecyclerAdapter);




    }
}

