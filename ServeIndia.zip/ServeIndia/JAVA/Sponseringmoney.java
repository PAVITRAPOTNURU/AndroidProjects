package com.example.serveindia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Sponseringmoney extends AppCompatActivity {
    EditText et1,et2,name,mobile,address;
    Button save,cancel;
    private FirebaseAuth mAuth;
    private DatabaseReference db_sp;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sponseringmoney);
        et1=findViewById(R.id.et_reqorp_amount);
        et2=findViewById(R.id.et_reqorp_purpose);
        name=findViewById(R.id.et_reqorp_username);
        mobile=findViewById(R.id.et_reqorp_phone);
        address=findViewById(R.id.et_reqorp_address);
        save=findViewById(R.id.bt_reqorp_save);
        cancel=findViewById(R.id.bt_reqorp_cancel);
        mAuth=FirebaseAuth.getInstance();
        db_sp= FirebaseDatabase.getInstance().getReference().child("Request to help").child("orphanage");
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String amount=et1.getText().toString().trim();
                String purpose=et2.getText().toString().trim();
                String username=name.getText().toString().trim();
                String contact=mobile.getText().toString().trim();
                String add=address.getText().toString().trim();




                String id=db_sp.push().getKey();
                Help ob=new Help(id,username,amount,purpose,contact,add);
                db_sp.child(id).setValue(ob);
                Toast.makeText(getApplicationContext(),"Request Sent",Toast.LENGTH_SHORT).show();
                et1.setText("");
                et2.setText("");
                name.setText("");
                mobile.setText("");
                address.setText("");



            }
        });

    }

}
