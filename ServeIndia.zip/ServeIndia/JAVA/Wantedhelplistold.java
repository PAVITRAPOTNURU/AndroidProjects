package com.example.serveindia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Wantedhelplistold extends AppCompatActivity {

    RecyclerView mrecyclerview;
    FirebaseDatabase mfbdb;
    DatabaseReference mdr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wantedhelplistold);



        mrecyclerview = findViewById(R.id.recyclerview);
        mrecyclerview.setHasFixedSize(true);
        mrecyclerview.setLayoutManager(new LinearLayoutManager(this));
        mfbdb = FirebaseDatabase.getInstance();
        mdr = mfbdb.getReference().child("Request to help").child("Oldagehomes");

    }



    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<Help,Holderhelperold> firebaseRecyclerAdapter=new
                FirebaseRecyclerAdapter<Help, Holderhelperold>(
                        Help.class,
                        R.layout.spvieworp,
                        Holderhelperold.class,
                        mdr
                ){
                    @Override
                    protected void populateViewHolder(Holderhelperold holderhelporp, Help help, int i) {
                        holderhelporp.setdetails(getApplicationContext(),help.getName(),help.getAmount(),help.getPurpose(),help.getContact(),help.getAddress());
                        Toast.makeText(getApplicationContext(),"asss",Toast.LENGTH_LONG).show();
                    }


                };
        mrecyclerview.setAdapter(firebaseRecyclerAdapter);




    }
}

