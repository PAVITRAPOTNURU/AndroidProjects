package com.example.serveindia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Registerblood extends AppCompatActivity {
    EditText reg_name;
    EditText reg_pwd;
    EditText reg_email;
    EditText reg_phone;
    EditText reg_address;
    Button reg_save;
    Button reg_cancel;
    FirebaseAuth mAuth;
    DatabaseReference db;
    String username;
    String phone;
    String email;
    String pwd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registerblood);
        reg_name=findViewById(R.id.et_username);
        reg_pwd=findViewById(R.id.et_pwd);
        reg_email=findViewById(R.id.et_email);
        reg_phone=findViewById(R.id.et_phone);
        reg_address=findViewById(R.id.et_address);
        reg_save=findViewById(R.id.bt_save);
        reg_cancel=findViewById(R.id.bt_cancel);
        mAuth= FirebaseAuth.getInstance();
        db= FirebaseDatabase.getInstance().getReference("Users").child("bloodbanks");
        reg_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username=reg_name.getText().toString();
                phone=reg_phone.getText().toString();
                email=reg_email.getText().toString();
                pwd=reg_pwd.getText().toString();

                if(validate(username,reg_name)&&validate(phone,reg_phone)&&validate(email,reg_email)&&validate(pwd,reg_pwd))
                {
                    Toast.makeText(getApplicationContext(),"validated",Toast.LENGTH_LONG).show();
                    register(email,pwd);


                }


            }


        });


    }

    private void register(final String email, final String pwd) {
        mAuth.createUserWithEmailAndPassword(email, pwd)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            User user=new User(username,phone,email);
                            db.child(mAuth.getUid()).setValue(user);
                            Toast.makeText(Registerblood.this,"Succes",Toast.LENGTH_LONG).show();

                            Intent it=new Intent(Registerblood.this,Blooddonarlogin.class);
                            startActivity(it);


                        }


                    }
                }).addOnFailureListener(this, new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(Registerblood.this,e.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }

    private boolean validate(String string ,EditText editText)
    {
        if(string.isEmpty())
        {
            editText.setError("plz enter the field");
            return  false;
        }
        return true;
    }
}