package com.example.serveindia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Login_ngos extends AppCompatActivity {

    EditText pwd_ngo;
    EditText email_ngo;
    Button login;
    Button reg;
    FirebaseAuth at;
    private DatabaseReference db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_ngos);

        email_ngo = findViewById(R.id.et_email);
        pwd_ngo = findViewById(R.id.et_pwd);
        login = findViewById(R.id.bt_login);
        reg = findViewById(R.id.bt_register);
        at = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance().getReference().child("Users").child("Ngo");
        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it = new Intent(Login_ngos.this, Registerngo.class);
                startActivity(it);

            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Intent it = new Intent(Login_donar.this, Foodactivity.class);
                //startActivity(it);

                String email_n = email_ngo.getText().toString();
                String pwd_n = pwd_ngo.getText().toString();
                Toast.makeText(getApplicationContext(), "cool", Toast.LENGTH_LONG).show();

                if (validate(email_n, email_ngo) && validate(pwd_n, pwd_ngo)) {
                    Toast.makeText(getApplicationContext(), "validated", Toast.LENGTH_LONG).show();
                    loginDon(email_n, pwd_n);

                }


            }
        });

    }

    private void loginDon(String email, String password) {
        at.signInWithEmailAndPassword(email, password).addOnSuccessListener(this, new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                db.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot data : dataSnapshot.getChildren()) {
                            if (data.getKey().equals(FirebaseAuth.getInstance().getUid())) {
                                startActivity(new Intent(Login_ngos.this, Selectionactivityorgngo.class));
                                break;
                            }
                        }

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });


                email_ngo.setText("");
                pwd_ngo.setText("");

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean validate(String string, EditText editText) {
        if (string.isEmpty()) {
            editText.setError("plz enter the field");
            return false;
        }
        return true;
    }

}