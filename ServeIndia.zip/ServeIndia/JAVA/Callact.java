package com.example.serveindia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Callact extends AppCompatActivity {
    //TextView tv;
   // ImageButton call;
    DatabaseReference myref_food;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_callact);
        ////tv=findViewById(R.id.textView2_c);
        //call=findViewById(R.id.call);
        myref_food = FirebaseDatabase.getInstance().getReference().child("Users").child("bloodbanks").child("Donated blood").child("O+");

        myref_food.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot data : dataSnapshot.getChildren()) {


                    Blooddonarslist blood = data.getValue(Blooddonarslist.class);
//System.out.println("name"+user.getUsername());
                    String data1=blood.getMobile();
                    //tv.setText(data1);
                    if(data1.isEmpty())
                    {
                        Toast.makeText(getApplicationContext(),"can't make a call",Toast.LENGTH_LONG).show();
                    }
                    else
                    {
                        String s="tel:"+data1;
                        Intent it=new Intent(Intent.ACTION_CALL);
                        it.setData(Uri.parse(s));
                        startActivity(it);
                    }

                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}

