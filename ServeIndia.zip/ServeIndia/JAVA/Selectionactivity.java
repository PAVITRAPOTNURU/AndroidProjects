package com.example.serveindia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Selectionactivity extends AppCompatActivity {
    ListView lv;
    ArrayList<String> al;
    ArrayAdapter<String> ad;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selectionactivity);
        lv=findViewById(R.id.lv_select);
        al=new ArrayList<String>();
        al.add("Food");
        al.add("Cloth");
        al.add("Books");
        al.add("Care");
        ad=new ArrayAdapter<String>(getApplicationContext(),R.layout.listview,al);
        lv.setAdapter(ad);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(i==0)
                {
                    Intent it=new Intent(Selectionactivity.this,Foodact.class);
                    startActivity(it);
                }
                if(i==1)
                {
                    Intent it=new Intent(Selectionactivity.this,Clothactivity.class);
                    startActivity(it);
                }
                if(i==2)
                {
                    Intent it=new Intent(Selectionactivity.this,Booksactivity.class);
                    startActivity(it);
                }
                if(i==3)
                {
                    Intent it=new Intent(Selectionactivity.this,Educateactivity.class);
                    startActivity(it);
                }

            }
        });


    }
}
