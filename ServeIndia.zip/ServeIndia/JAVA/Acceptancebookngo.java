package com.example.serveindia;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Acceptancebookngo extends AppCompatActivity {
    Button bt;
    DatabaseReference mdr;
    String imageurl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acceptancebookngo);

        bt=findViewById(R.id.acceptbookngo);
        Intent it=getIntent();
        imageurl=it.getStringExtra("c");
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                removeFromList();

            }
        });

    }



    public void removeFromList()
    {

        mdr = FirebaseDatabase.getInstance().getReference().child("Books").child("Books_Ngo");
        mdr.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot data:dataSnapshot.getChildren())
                {
                    ImageUploadInfo value = data.getValue(ImageUploadInfo.class);
                    // System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA"+value.getContact());
                    if(value.getImageURL().equals(imageurl))
                    {
                        mdr.child(data.getKey()).removeValue();
                        //System.out.println("$$$EEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE"+value.getContact());
                        break;
                    }


                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }


}

