package com.example.serveindia;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class BloodreceiveApos extends AppCompatActivity {
    RecyclerView mrecyclerview;
    FirebaseDatabase mfbdb;
    DatabaseReference mdr;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bloodreceive_apos);
        mrecyclerview = findViewById(R.id.recyclerview);
        mrecyclerview.setHasFixedSize(true);
        mrecyclerview.setLayoutManager(new LinearLayoutManager(this));
        mfbdb = FirebaseDatabase.getInstance();
        mdr = mfbdb.getReference().child("Users").child("bloodbanks").child("Donated blood").child("A+");

    }






@Override
protected void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<Blooddonarslist,BloodreceivehelpApos> firebaseRecyclerAdapter=new
        FirebaseRecyclerAdapter<Blooddonarslist,BloodreceivehelpApos>(
        Blooddonarslist.class,
        R.layout.bloodviewlayout,
        BloodreceivehelpApos.class,
        mdr
        ){

@Override
protected void populateViewHolder(BloodreceivehelpApos bloodreceivehelp, Blooddonarslist blooddonarslist, int i) {
        bloodreceivehelp.setdetails(getApplicationContext(),blooddonarslist.getUsername(),blooddonarslist.getMobile(),blooddonarslist.getGender());
        }
        };
        mrecyclerview.setAdapter(firebaseRecyclerAdapter);




        }
        }
