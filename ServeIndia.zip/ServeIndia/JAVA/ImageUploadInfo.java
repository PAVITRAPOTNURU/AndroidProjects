package com.example.serveindia;



public class ImageUploadInfo {

    public String address;
    public String imageURL;
    public String quantity;
    public String item;



    public ImageUploadInfo() {

    }
    public ImageUploadInfo(String imageurl) {


        this.imageURL=imageURL;

    }

   public ImageUploadInfo(String imageurl,String address) {


        this.imageURL=imageURL;

        this.address=address;

    }
    public ImageUploadInfo( String imageURL, String quantity,String item,String address)
    {



        this.imageURL=imageURL;
        this.quantity=quantity;
        this.item=item;
        this.address=address;

    }



    public ImageUploadInfo( String imageURL, String quantity,String address)
    {



        this.imageURL=imageURL;
        this.quantity=quantity;
        this.address=address;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress() {
        return address;
    }


    public void setImageURL(String imageURL) {
        this.imageURL = imageURL;
    }

    public String getImageURL() {
        return imageURL;
    }



    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getQuantity() {
        return quantity;
    }

}