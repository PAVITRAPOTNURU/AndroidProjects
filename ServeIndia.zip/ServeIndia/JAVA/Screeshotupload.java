package com.example.serveindia;

public class Screeshotupload {
    String sponsername;
    String name;
    String amountoffered;
    String transid;

    String imageurl;

    public Screeshotupload()
    {

    }
public Screeshotupload(String sponsername,String name,String amountoffered,String transid,String imageurl)
{
    this.sponsername=sponsername;
    this.name=name;
    this.amountoffered=amountoffered;
    this.transid=transid;

    this.imageurl=imageurl;
}

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }

    public String getSponsername() {
        return sponsername;
    }

    public void setSponsername(String sponsername) {
        this.sponsername = sponsername;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAmountoffered() {
        return amountoffered;
    }

    public void setAmountoffered(String amountoffered) {
        this.amountoffered = amountoffered;
    }

    public String getTransid() {
        return transid;
    }

    public void setTransid(String transid) {
        this.transid = transid;
    }


}