package com.example.serveindia;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Secondactivity extends AppCompatActivity {
    Button donor;
    Button orphanages;
    Button oldagehomes;
    Button ngo;
    Button sponsers;
    Button bloodbanks;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_secondactivity);
        donor=findViewById(R.id.button6);
        orphanages=findViewById(R.id.button7);
        oldagehomes=findViewById(R.id.button9);
        ngo=findViewById(R.id.button5);
        bloodbanks=findViewById(R.id.button11);
        sponsers=findViewById(R.id.button13);
        donor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(Secondactivity.this,Login_donar.class);

                startActivity(it);

            }
        });
        orphanages.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it2=new Intent(Secondactivity.this,Login_orphanages.class);
                startActivity(it2);

            }
        });
        ngo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it2=new Intent(Secondactivity.this,Login_ngos.class);
                startActivity(it2);

            }
        });

        sponsers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it2=new Intent(Secondactivity.this,Login_Sponsersact.class);
                startActivity(it2);

            }
        });
        oldagehomes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it2=new Intent(Secondactivity.this,Login_oldagehomes.class);
                startActivity(it2);

            }
        });
        bloodbanks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it=new Intent(Secondactivity.this,Blooddonarlogin.class);

                startActivity(it);


            }
        });


    }
}
